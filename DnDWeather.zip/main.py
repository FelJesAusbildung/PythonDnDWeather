import json
import random


def roll_chance_items(items):
    total_chance = 0
    for item in items:
        total_chance += item['chance']
    random_chance = random.randint(1, total_chance + 1)
    for ordinal in range(0, len(items)):
        if random_chance > 0:
            random_chance -= items[ordinal]['chance']
        else:
            chosen = items[ordinal - 1]
            break
        chosen = items[len(items) - 1]
    return chosen


def roll_weather():
    with open("Weather.json", "r") as weather_file:
        weathers = json.load(weather_file)
        chosen_weather = roll_chance_items(weathers)
        print("{}".format(chosen_weather['flavor']))
        roll_wind(chosen_weather)


def roll_encounter():
    with open("SailingEncounter.json", "r") as encounter_file:
        encounters = json.load(encounter_file)
        chosen_encounter = roll_chance_items(encounters)
        if chosen_encounter['flavor'] != "":
            print("{}".format(chosen_encounter['flavor']))


def roll_wind(weather):
    with open("Wind.json", "r") as wind_file:
        winds = json.load(wind_file)
        for wind in winds:
            if weather['isApocalypse']:
                wind['chance'] = wind['apocalypseChance']
            else:
                wind['chance'] = wind['nonApocalypseChance']
        chosen_wind = roll_chance_items(winds)
        speed = random.randint(chosen_wind['minSpeed'], chosen_wind['maxSpeed'])
        directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
        direction = random.choice(directions)
        print("{}, Wind Speed: {}km/h, Wind Direction: {}".format(chosen_wind['flavor'], speed, direction))


weeks = int(input('number of weeks to calculate: \n'))
for number in range(0, weeks):
    print()
    print("Week {}:".format(number + 1))
    roll_encounter()
    roll_weather()
